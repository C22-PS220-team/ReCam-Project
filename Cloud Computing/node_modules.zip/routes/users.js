var express = require('express');

var hoteljsonFile = require("../data.json"); 
const router = express.Router();

router.get('/', (req, res) =>
{
    res.json(hoteljsonFile);
} );

module.exports = router;